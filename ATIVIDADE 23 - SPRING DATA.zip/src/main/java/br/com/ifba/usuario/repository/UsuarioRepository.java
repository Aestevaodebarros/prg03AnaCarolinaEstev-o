package br.com.ifba.usuario.repository;

import br.com.ifba.usuario.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

/**
 * Atividade 23: substitui GenericIDao/GenericDao/UsuarioIDao/UsuarioDao.
 * O Spring Data gera a implementacao em tempo de execucao; save, delete,
 * findAll e findById ja vem de {@link JpaRepository}.
 */
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    /** Consulta derivada do nome (Task 04): vira um SELECT ... WHERE login = ?. */
    Optional<Usuario> findByLogin(String login);

    /**
     * Task 04: so responde "existe?" - o banco devolve um boolean e nenhum
     * Usuario (com cpf, senha, endereco...) precisa ser carregado so para
     * ser comparado com null.
     */
    boolean existsByLogin(String login);

    /**
     * Task 05: o equivalente derivado seria
     * {@code findByLoginContainingIgnoreCaseOrNomeContainingIgnoreCaseOrderByNomeAsc(String, String)}
     * - ilegivel, e ainda exigiria passar o mesmo termo duas vezes. Com
     * {@code @Query} a regra fica escrita como JPQL: login OU nome contem o
     * termo (sem diferenciar maiusculas), do A ao Z pelo nome.
     */
    @Query("SELECT u FROM Usuario u "
            + "WHERE LOWER(u.login) LIKE LOWER(CONCAT('%', :termo, '%')) "
            + "OR LOWER(u.nome) LIKE LOWER(CONCAT('%', :termo, '%')) "
            + "ORDER BY u.nome ASC")
    List<Usuario> buscarPorLoginOuNome(@Param("termo") String termo);
}

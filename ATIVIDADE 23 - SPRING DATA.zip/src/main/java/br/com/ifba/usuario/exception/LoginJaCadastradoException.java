package br.com.ifba.usuario.exception;

/**
 * Lancada pelo UsuarioService ao tentar cadastrar um login que ja existe.
 * RuntimeException pelo mesmo motivo de {@link UsuarioNaoEncontradoException}:
 * quem precisa tratar e so a tela de cadastro.
 */
public class LoginJaCadastradoException extends RuntimeException {

    public LoginJaCadastradoException(String login) {
        super("Ja existe um usuario cadastrado com o login \"" + login + "\".");
    }
}

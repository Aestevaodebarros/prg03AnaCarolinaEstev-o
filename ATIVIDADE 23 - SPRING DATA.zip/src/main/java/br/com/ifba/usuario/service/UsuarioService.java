package br.com.ifba.usuario.service;

import br.com.ifba.usuario.entity.Usuario;
import br.com.ifba.usuario.exception.LoginJaCadastradoException;
import br.com.ifba.usuario.exception.UsuarioNaoEncontradoException;
import br.com.ifba.usuario.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Atividade 23: regras de negocio de Usuario. As telas falam so com este
 * servico; ele fala com o {@link UsuarioRepository}. O repositorio chega
 * pelo construtor (injecao feita pelo Spring), o que tambem permite
 * trocar por um falso nos testes.
 */
@Service
public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService(UsuarioRepository repository) {
        this.repository = repository;
    }

    /**
     * Task 04: antes a tela buscava o Usuario inteiro e testava
     * {@code != null}; agora o banco so responde sim/nao.
     */
    public boolean loginJaCadastrado(String login) {
        return repository.existsByLogin(login);
    }

    /** @throws LoginJaCadastradoException se o login ja estiver em uso. */
    public void cadastrar(Usuario usuario) {
        if (loginJaCadastrado(usuario.getLogin())) {
            throw new LoginJaCadastradoException(usuario.getLogin());
        }
        repository.save(usuario);
    }

    public void atualizar(Usuario usuario) {
        repository.save(usuario);
    }

    public void remover(Usuario usuario) {
        repository.delete(usuario);
    }

    public Optional<Usuario> buscarPorLogin(String login) {
        return repository.findByLogin(login);
    }

    /** @throws UsuarioNaoEncontradoException se nao existir usuario com o login. */
    public Usuario buscarPorLoginOuFalhar(String login) {
        return repository.findByLogin(login)
                .orElseThrow(() -> new UsuarioNaoEncontradoException(login));
    }

    public List<Usuario> listarTodos() {
        return repository.findAll();
    }

    public List<Usuario> buscarPorTermo(String termo) {
        return repository.buscarPorLoginOuNome(termo);
    }
}

package br.com.ifba.infrastructure.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

/**
 * Atividade 19 - Task 01: superclasse de toda entidade JPA do projeto.
 *
 * {@code @MappedSuperclass} (e não {@code @Entity}): esta classe não tem
 * tabela própria — ela só existe para que as colunas {@code id} fiquem
 * declaradas uma única vez e sejam herdadas (mapeadas na tabela de cada
 * subclasse) por toda entidade do domínio. Uma entidade não "é um"
 * PersistenceEntity no sentido de negócio (não existe um
 * {@code List<PersistenceEntity>} fazendo sentido no domínio) — é herança
 * puramente técnica, de infraestrutura, por isso vive no pacote
 * {@code infrastructure}, separado do domínio ({@code usuario},
 * {@code academico}...).
 *
 * Atividade 23: o {@code JpaRepository<Usuario, Long>} do Spring Data usa o
 * {@code Long} deste {@code id} como tipo da chave primária.
 */
public abstract class PersistenceEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}

package br.com.ifba;

import br.com.ifba.login.view.TelaLogin;
import br.com.ifba.usuario.service.UsuarioService;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

import javax.swing.SwingUtilities;

/**
 * Atividade 23: ponto de entrada. Sobe o Spring (que le o
 * application.properties, conecta no banco, valida o schema e cria os
 * repositorios) e so depois abre a Tela de Login, entregando a ela o
 * {@link UsuarioService} ja montado pelo Spring.
 *
 * As telas continuam sendo criadas com {@code new} (Swing nao e gerenciado
 * pelo Spring); o que muda e que elas recebem o servico pelo construtor em
 * vez de criar o proprio acesso ao banco.
 */
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        // headless(false): sem isso o Spring Boot desliga o ambiente grafico
        // e qualquer JFrame lanca HeadlessException.
        ConfigurableApplicationContext contexto =
                new SpringApplicationBuilder(Application.class).headless(false).run(args);

        UsuarioService usuarioService = contexto.getBean(UsuarioService.class);
        SwingUtilities.invokeLater(() -> new TelaLogin(usuarioService).setVisible(true));
    }
}

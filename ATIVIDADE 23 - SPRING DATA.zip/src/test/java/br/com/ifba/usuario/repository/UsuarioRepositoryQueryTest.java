package br.com.ifba.usuario.repository;

import br.com.ifba.usuario.entity.Usuario;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Atividade 23 - Task 04 e 05: testa as consultas do UsuarioRepository de
 * verdade, contra um H2 em memoria (o @DataJpaTest troca o MySQL do
 * application.properties por ele). O ddl-auto vira create-drop so aqui,
 * porque o H2 nasce vazio e o "validate" da aplicacao exigiria tabelas ja
 * criadas.
 */
@DataJpaTest(properties = "spring.jpa.hibernate.ddl-auto=create-drop")
class UsuarioRepositoryQueryTest {

    @Autowired
    private UsuarioRepository repository;

    private Usuario novo(String nome, String cpf, String email, String login) {
        return new Usuario(nome, cpf, "Outro", "01/01/2000", "7199999999", email, login, "abc123");
    }

    private List<String> logins(List<Usuario> usuarios) {
        return usuarios.stream().map(Usuario::getLogin).collect(Collectors.toList());
    }

    @Test
    void existsByLoginDizSimParaLoginCadastradoENaoParaOutro() {
        repository.save(novo("Ana Souza", "11111111111", "ana@ifba.local", "ana"));

        assertTrue(repository.existsByLogin("ana"));
        assertFalse(repository.existsByLogin("bia"));
    }

    @Test
    void buscarPorLoginOuNomeEncontraPeloLoginOuPeloNomeSemDiferenciarMaiusculas() {
        repository.save(novo("Carlos Lima", "22222222222", "carlos@ifba.local", "clima"));
        repository.save(novo("Joana Ana", "33333333333", "joana@ifba.local", "joana"));
        repository.save(novo("Bruno Dias", "44444444444", "bruno@ifba.local", "bruno"));

        // "ANA" aparece no NOME de Joana Ana e nao aparece em mais ninguem
        assertEquals(List.of("joana"), logins(repository.buscarPorLoginOuNome("ANA")));
        // "clim" aparece so no LOGIN de Carlos
        assertEquals(List.of("clima"), logins(repository.buscarPorLoginOuNome("clim")));
    }

    @Test
    void buscarPorLoginOuNomeDevolveOrdenadoPeloNome() {
        repository.save(novo("Zeca Prado", "55555555555", "zeca@ifba.local", "usuario3"));
        repository.save(novo("Alice Prado", "66666666666", "alice@ifba.local", "usuario1"));
        repository.save(novo("Mario Prado", "77777777777", "mario@ifba.local", "usuario2"));

        assertEquals(List.of("usuario1", "usuario2", "usuario3"),
                logins(repository.buscarPorLoginOuNome("prado")));
    }
}

package br.com.ifba.usuario.service;

import br.com.ifba.usuario.entity.Usuario;
import br.com.ifba.usuario.exception.LoginJaCadastradoException;
import br.com.ifba.usuario.exception.UsuarioNaoEncontradoException;
import br.com.ifba.usuario.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Atividade 23 - Task 04: testa a regra "login nao pode repetir" do
 * UsuarioService sem banco e sem Spring. O repositorio e um objeto falso
 * (java.lang.reflect.Proxy): so os metodos que o servico usa respondem; os
 * demais da interface JpaRepository nao precisam ser implementados.
 */
class UsuarioServiceTest {

    /** Repositorio falso: guarda usuarios por login e anota o que foi chamado. */
    private final Map<String, Usuario> banco = new HashMap<>();
    private final List<String> chamadas = new ArrayList<>();
    private UsuarioService servico;

    @BeforeEach
    void montarServicoComRepositorioFalso() {
        banco.clear();
        chamadas.clear();
        UsuarioRepository repositorioFalso = (UsuarioRepository) Proxy.newProxyInstance(
                UsuarioRepository.class.getClassLoader(),
                new Class<?>[]{UsuarioRepository.class},
                (proxy, metodo, args) -> {
                    chamadas.add(metodo.getName());
                    switch (metodo.getName()) {
                        case "existsByLogin":
                            return banco.containsKey(args[0]);
                        case "findByLogin":
                            return Optional.ofNullable(banco.get(args[0]));
                        case "save":
                            Usuario salvo = (Usuario) args[0];
                            banco.put(salvo.getLogin(), salvo);
                            return salvo;
                        default:
                            throw new UnsupportedOperationException(metodo.getName());
                    }
                });
        servico = new UsuarioService(repositorioFalso);
    }

    @Test
    void cadastrarSalvaQuandoOLoginEstaLivre() {
        servico.cadastrar(new Usuario("ana", "abc123"));

        assertTrue(banco.containsKey("ana"));
    }

    @Test
    void cadastrarLancaExcecaoQuandoOLoginJaExiste() {
        banco.put("ana", new Usuario("ana", "abc123"));

        assertThrows(LoginJaCadastradoException.class,
                () -> servico.cadastrar(new Usuario("ana", "outra1")));
    }

    @Test
    void cadastrarComLoginRepetidoNaoChegaASalvar() {
        banco.put("ana", new Usuario("ana", "abc123"));

        assertThrows(LoginJaCadastradoException.class,
                () -> servico.cadastrar(new Usuario("ana", "outra1")));

        assertFalse(chamadas.contains("save"), "nao deveria ter chamado save");
        assertEquals("abc123", banco.get("ana").getSenha());
    }

    @Test
    void loginJaCadastradoPerguntaSoExistsByLoginENaoCarregaOUsuario() {
        banco.put("ana", new Usuario("ana", "abc123"));

        assertTrue(servico.loginJaCadastrado("ana"));
        assertFalse(servico.loginJaCadastrado("bia"));

        assertEquals(List.of("existsByLogin", "existsByLogin"), chamadas);
    }

    @Test
    void buscarPorLoginOuFalharLancaExcecaoQuandoNaoExiste() {
        assertThrows(UsuarioNaoEncontradoException.class,
                () -> servico.buscarPorLoginOuFalhar("fantasma"));
    }
}

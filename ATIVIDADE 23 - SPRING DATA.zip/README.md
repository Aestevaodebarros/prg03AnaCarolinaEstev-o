# prg0AnaCarolina- Sistema Academico

Projeto Java Maven com as telas de Login e Cadastro de Usuario (Atividades 04 a 07).

# Estrutura do projeto
src/
└── main/
    └── java/
        └── br/
            └── com/
                └── ifba/
                    ├── login/
                    │   └── view/
                    │       └── TelaLogin.java
                    └── usuario/
                        ├── entity/
                        │   └── Usuario.java
                        ├── validar/
                        │   └── ValidadorUsuario.java
                        └── view/
                            └── TelaCadastroUsuario.java

## Como rodar
mvn compile exec:java -Dexec.mainClass=br.com.ifba.login.view.TelaLogin
(ou importe como projeto Maven na sua IDE e rode a classe TelaLogin)

## Estrutura de pacotes
- br.com.ifba.login.view      -> TelaLogin
- br.com.ifba.login.imagens   -> imagens da tela de login (logo.png etc.)
- br.com.ifba.usuario.view    -> TelaCadastroUsuario
- br.com.ifba.usuario.imagens -> imagens das telas de usuario
- br.com.ifba.usuario.validar -> ValidadorUsuario (metodo estatico)
- br.com.ifba.usuario.entity  -> Usuario (classe de dominio)

## Atividades cobertas
- [04] Projeto Java + Tela de Login (Tasks 01-03)
- [05] Tela de Cadastro de Usuario + link "Nao tenho conta? Cadastre-se" + validacoes com if/else
- [06] Classe ValidadorUsuario com metodo estatico contemPalavraProibida
- [07] Classe de dominio Usuario, instanciada nos botoes Cadastrar e Entrar

## Atividade 13 - Polimorfismo

### Task 04 - Sobrecarga onde ela faz sentido

`Usuario` tem dois construtores com o mesmo nome e listas de parâmetros
diferentes:

- `Usuario(String login, String senha)` — só os campos **obrigatórios**,
  usado na Tela de Login, onde a pessoa só digita login e senha.
- `Usuario(String nome, String cpf, String genero, String dataNascimento,
  String telefone, String email, String login, String senha)` — **todos os
  campos**, usado na Tela de Cadastro, onde o cadastro completo é
  preenchido de uma vez.

As duas versões existem porque são dois momentos reais e diferentes do
sistema (logar vs. cadastrar), cada um com um conjunto diferente de dados
disponíveis — não é sobrecarga sem motivo nem código duplicado: a versão
curta simplesmente delega para a versão completa (`this(null, null, ...,
login, senha)`), preenchendo com `null` o que ainda não existe.

### Polimorfismo via interface (Tasks 01, 02, 03 e 05)

- `Autenticavel.autenticar(String, String)` agora **devolve** uma `String`
  (a mensagem) em vez de imprimir ou devolver `boolean` (Task 02).
- `Usuario` e `Administrador` implementam `autenticar(...)` de formas
  diferentes — `Administrador` não herda de `Usuario`, é uma classe
  totalmente separada que só compartilha o contrato `Autenticavel`
  (Task 01).
- `Autenticavel.processar(Autenticavel pessoa, String login, String senha)`
  é um método estático que recebe sempre o tipo geral e nunca sabe qual
  classe concreta chegou (Task 03).
- Testes em `PolimorfismoAutenticacaoTest` comprovam que cada classe
  responde do seu próprio jeito ao mesmo método (Task 05).

## Atividade 15 - Collections (Guardando os seus objetos)

### Task 01 - Repositório em memória

`RepositorioUsuarioEmMemoria` guarda os usuários em um
`private final List<Usuario> usuarios = new ArrayList<>();`, com
`cadastrar(Usuario)` e `listarTodos()` (devolve `List<Usuario>` imutável,
via `List.copyOf`). `TelaCadastroUsuario` e `TelaLogin` agora compartilham
a mesma instância do repositório — nada mais de usuário cadastrado e
esquecido numa variável local que morre quando a tela fecha.

### Task 02 - Usuario sabe se comparar

`Usuario.equals`/`Usuario.hashCode` comparam pelo `login` (não pelo CPF):
é o campo que o próprio sistema já usa para autenticar e indexar, e nem
todo `Usuario` tem CPF preenchido (o construtor simplificado da Tela de
Login só tem login/senha). Antes dessa implementação,
`usuarios.contains(outroComMesmoLogin)` devolvia `false` mesmo com o mesmo
login — dois objetos diferentes eram "diferentes" para a lista. Depois,
devolve `true`: é a mesma lista, o mesmo método `contains`, mas a resposta
muda porque quem decide o que é "igual" é a classe `Usuario`, não a
coleção (teste: `RepositorioUsuarioEmMemoriaTest.
doisObjetosDiferentesComOMesmoLoginSaoIguaisParaALista`).

### Task 03 - Índice por login: List (for) vs. Map

`buscarPorLoginComFor(login)` percorre a `List` inteira com um `for` até
achar o login (ou chegar ao fim); `buscarPorLogin(login)` usa o
`HashMap<String, Usuario> porLogin`, alimentado a cada `cadastrar(...)`.

Com **dez usuários** a diferença é imperceptível — os dois terminam
"instantaneamente". Com **dez mil usuários**, a busca pela `List` é O(n):
no pior caso (login inexistente, ou o último da lista) o laço compara os
dez mil registros toda vez que alguém tenta entrar. A busca pelo `Map` é
O(1) em média: o `HashMap` calcula o hash do login e vai direto ao balde
certo, então o tempo de busca não cresce com o tamanho da base.

## Atividade 14 - JPA e Hibernate (Parte 1)

Detalhes completos e a justificativa de cada Task em
`atividade14-justificativa-pr.md`; a resposta da Task 06 (DTO) está em
`RETROSPECTIVA.md`. Resumo:

- **Task 01:** `hibernate-core` + driver MySQL no `pom.xml`;
  `persistence.xml.exemplo` versionado (sem credenciais) em
  `src/main/resources/META-INF`.
- **Task 02:** `Usuario` (classe central do domínio) mapeada com
  `@Entity`, `@Table`, `@Id`/`@GeneratedValue` (novo campo técnico `id`),
  `@Column` onde o nome da coluna precisou fugir do padrão, `@Embedded`
  para `Endereco` (reflexo da composição da Atividade 11) e
  `@Enumerated(STRING)` para `status`.
- **Task 03:** pacotes já seguiam `entity`/`view`; imagens do projeto
  vivem em `src/main/resources` (recurso estático, fora de `src/main/java`).
- **Task 04:** três telas (cadastro, listagem, edição) — só os
  componentes visuais, nenhum código de JPA/Hibernate ainda nelas.
- **Task 05:** suíte de testes inteira (30/30) continua verde — ver
  `atividade14-suite-de-testes-executada.txt`.
- **Task 06:** respondida em `RETROSPECTIVA.md`.

## Atividade 17 - CRUD completo com JPA (tratamento de erros)

Detalhes completos em `atividade17-justificativa-pr.md`. Resumo:

- **Task 01:** `JPAUtil` (`br.com.ifba.infrastructure.util`) cria o
  `EntityManagerFactory` uma única vez; nenhuma tela cria a fábrica.
- **Task 02:** `RepositorioUsuario` substitui o repositório em memória da
  Atividade 15 — `cadastrar` usa `persist`, `listarTodos`/`buscarPorLogin`
  usam JPQL, `editar` usa `merge`, `remover` usa `merge` + `remove`, tudo
  dentro de `begin()`/`commit()`.
- **Task 03/04:** `UsuarioNaoEncontradoException` (novo), lançada por
  `buscarPorLoginOuFalhar` no lugar de devolver `null` — usada por
  `TelaEditarUsuario` (ver a justificativa completa do "antes/depois" no
  PR).
- **Task 05/06:** toda chamada ao repositório nas telas está em
  `try/catch` com `JOptionPane`; todo método do repositório fecha o
  `EntityManager` em `finally` e dá `rollback()` só se a transação
  seguir ativa.
- **Task 07:** busca da listagem agora usa JPQL com `WHERE`
  (`buscarPorTermo`).
- **Task 08:** `RepositorioUsuarioTest` cobre o CRUD completo e a
  exceção (`assertThrows`/`assertDoesNotThrow`) — 34/34 testes passam,
  ver `atividade17-suite-de-testes-executada.txt`.

## Atividade 23 - Spring Data no projeto

Detalhes, `git diff --stat` e limitações em `ATIVIDADE 23 - SPRING DATA/README.md`. Resumo:

- **Task 01:** parent Spring Boot 2.7.18 + `spring-boot-starter-data-jpa`; `application.properties`
  com MySQL, `ddl-auto=validate` e `spring.main.headless=false`; nova classe `Application`.
- **Task 02:** removidos `GenericDao`, `GenericIDao`, `UsuarioDao`, `UsuarioIDao`, `JPAUtil`
  (e `PersistenciaException`) — 473 linhas removidas no commit (336 só dos cinco arquivos pedidos).
- **Task 03:** os 5 testes antigos seguem intocados e verdes (31/31 com os novos).
- **Task 04:** `existsByLogin` no `UsuarioRepository`, usado pelo `UsuarioService`; `UsuarioServiceTest`.
- **Task 05:** `@Query` `buscarPorLoginOuNome` (login ou nome, ordenado por nome); `UsuarioRepositoryQueryTest`.

# Atividade 23 - Spring Data no projeto

Branch: `feature/atividade-23-spring-data`

## Task 01 - Dependência e configuração
- `pom.xml`: parent `spring-boot-starter-parent 2.7.18` + `spring-boot-starter-data-jpa`
  (+ driver MySQL, `spring-boot-starter-test`, H2 só em teste). Escolhi o Boot **2.7**
  porque o projeto é Java 11 e usa `javax.persistence`; o Boot 3 exige Java 17 e `jakarta.*`.
  O `hibernate-core` e o `junit-jupiter` declarados à mão foram removidos (o parent escolhe versões compatíveis).
- `src/main/resources/application.properties`: datasource MySQL, `spring.jpa.hibernate.ddl-auto=validate`
  e `spring.main.headless=false` (sem ele o Swing lança `HeadlessException`).
  Usuário/senha vêm das variáveis `DB_USERNAME`/`DB_PASSWORD` — nada de credencial no repositório.
- Nova classe `Application` (`@SpringBootApplication`) sobe o Spring e abre a `TelaLogin`.

## Task 02 - O que ficou sem dono
Apagados: `GenericDao`, `GenericIDao`, `UsuarioDao`, `UsuarioIDao` (o único DAO concreto), `JPAUtil`
e também `PersistenciaException` (só o `GenericDao` a lançava).

`git diff --stat main..HEAD` do commit:

```
 pom.xml                                            |  79 ++++++-------
 src/main/java/br/com/ifba/Application.java         |  33 ++++++
 .../br/com/ifba/infrastructure/dao/GenericDao.java | 125 ---------------------
 .../com/ifba/infrastructure/dao/GenericIDao.java   |  53 ---------
 .../infrastructure/entity/PersistenceEntity.java   |   6 +-
 .../exception/PersistenciaException.java           |  24 ----
 .../br/com/ifba/infrastructure/util/JPAUtil.java   |  56 ---------
 .../java/br/com/ifba/login/view/TelaLogin.java     |  34 +++---
 .../java/br/com/ifba/usuario/dao/UsuarioDao.java   |  65 -----------
 .../java/br/com/ifba/usuario/dao/UsuarioIDao.java  |  37 ------
 .../exception/LoginJaCadastradoException.java      |  13 +++
 .../exception/UsuarioNaoEncontradoException.java   |   6 +-
 .../ifba/usuario/repository/UsuarioRepository.java |  40 +++++++
 .../com/ifba/usuario/service/UsuarioService.java   |  68 +++++++++++
 .../com/ifba/usuario/view/TelaCadastroUsuario.java |  42 +++----
 .../com/ifba/usuario/view/TelaEditarUsuario.java   |  25 ++---
 .../com/ifba/usuario/view/TelaListarUsuarios.java  |  33 +++---
 src/main/resources/application.properties          |  16 +++
 .../repository/UsuarioRepositoryQueryTest.java     |  65 +++++++++++
 .../ifba/usuario/service/UsuarioServiceTest.java   | 101 +++++++++++++++++
 20 files changed, 448 insertions(+), 473 deletions(-)
```

**Linhas removidas no total: 473** (448 inseridas). Só dos arquivos pedidos
(GenericDao 125 + GenericIDao 53 + UsuarioDao 65 + UsuarioIDao 37 + JPAUtil 56) são **336**;
com `PersistenciaException` (24) são 360; o resto são linhas trocadas nas telas e no pom.
> Este diff foi gerado em um repositório-snapshot criado aqui (não havia git no projeto).
> Rode `git diff --stat main..HEAD` no seu repositório e confira/substitua os números antes do PR.

## Task 03 - A suíte não muda
Os 5 testes antigos (26 testes) **não foram alterados** e continuam verdes; com os 5 novos do
`UsuarioServiceTest` são 31/31 — ver `suite-de-testes-executada.txt`.
**Os prints (barra verde e tela abrindo) precisam ser tirados por você** (`mvn test` / IDE e
`mvn spring-boot:run` com o MySQL de pé): não consigo gerar um print real aqui. Salve-os nesta pasta.

## Task 04 - `existsByLogin`
`UsuarioRepository.existsByLogin(String)`. `UsuarioService.loginJaCadastrado` e `cadastrar` o usam no lugar do
`findByLogin(...) != null` que a `TelaCadastroUsuario` fazia (carregava o usuário inteiro só para comparar com null).
Testes: `UsuarioServiceTest` (repositório falso via `Proxy`; inclui a prova de que só `existsByLogin` é chamado e
de que `save` não é chamado com login repetido) e `UsuarioRepositoryQueryTest`.

## Task 05 - `@Query`
`UsuarioRepository.buscarPorLoginOuNome(termo)`: login OU nome contém o termo, sem diferenciar maiúsculas,
**ordenado por nome**. O nome derivado seria
`findByLoginContainingIgnoreCaseOrNomeContainingIgnoreCaseOrderByNomeAsc(termo, termo)`.
É a busca da `TelaListarUsuarios`. Teste: `UsuarioRepositoryQueryTest` (`@DataJpaTest` + H2).

## O que NÃO foi verificado aqui (confira na sua máquina)
1. **Nada foi executado com Spring/Hibernate/MySQL reais** (Maven Central bloqueado). O código foi compilado contra stubs
   e o `UsuarioServiceTest` rodou de verdade, mas `UsuarioRepositoryQueryTest` (o único que prova o JPQL e o `existsByLogin`)
   **só foi compilado**. Rode `mvn test` e me diga se algo falhar.
2. `ddl-auto=validate` exige que as tabelas **já existam** (o projeto não tem migrations/Flyway). Crie a `tb_usuario`
   antes de subir a aplicação, ou o Spring recusa a iniciar.
3. `existsByLogin` é sensível a maiúsculas conforme a collation do banco (no MySQL padrão é insensível, como era o
   `LOWER(...)` do DAO antigo); no H2 de teste é sensível.
4. As telas agora recebem o `UsuarioService` pelo construtor; `TelaLogin.main` foi removido — a entrada é `Application`.

## Fluxo de entrega
```
git checkout -b feature/atividade-23-spring-data
git add -A && git commit -m "feat: migra persistencia para Spring Data JPA"
git push -u origin feature/atividade-23-spring-data
# abrir PR -> revisar o diff -> merge -> deletar a branch
```
